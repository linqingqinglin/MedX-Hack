(function(window, undefined) {
  var dictionary = {
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Desktop layout",
    "e49c6352-12e7-402c-b21e-a76598afbabc": "login_page",
    "9c7d3a4b-0bc8-4f9f-a242-5846a245ec6c": "user_consent",
    "61509c4e-362b-4ee1-bef3-fcd9fe5c3257": "volunteer_record",
    "74804a94-63a3-442e-8471-19c8098cc509": "user_login",
    "80c3cedb-4e48-4602-bd61-96aa60736d9b": "Mobile layout",
    "86c95955-fa8c-4ad4-9ba9-d9bd769bb5dd": "admin_login",
    "04104089-3d8a-4c3f-85bf-d0484d150861": "volunteer_consent",
    "a44e9ed5-10aa-4941-9e1b-dda301ad817a": "volunteer_date1_3",
    "0c63c8d5-a475-472e-aea3-1a62bdde3a08": "volunteer_date1_2",
    "2c45c2a1-0336-43fd-b4a1-7712f3aa6a93": "contact",
    "237d2074-94c7-47c6-a764-4c01c53072c5": "Tablet layout",
    "701549f2-62bb-47b1-947c-17761bd33c6f": "DBS",
    "11055585-85de-4338-90fb-cbb1e5fe2ade": "volunteer_login",
    "17d28d4e-e2e1-484c-85a6-738b33dcf081": "ns_surgeries",
    "96bf1caf-a492-4434-83a8-5eba13e41d7a": "user_record",
    "298ee4e4-0017-4a64-ba4c-3a91d1f3aa3d": "volunteer_date1",
    "87db3cf7-6bd4-40c3-b29c-45680fb11462": "960 grid - 16 columns",
    "e5f958a4-53ae-426e-8c05-2f7d8e00b762": "960 grid - 12 columns",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);